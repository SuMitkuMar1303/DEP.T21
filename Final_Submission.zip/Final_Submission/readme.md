Unzip the file and move it to a desired location.
Make sure your device has NodeJS and Node Package Manager installed.
Open a terminal with the path of the folder.
Run the command– npm install 
Run the command– npm start 
On connection you will see the message– server is up! Mongo DB connected
