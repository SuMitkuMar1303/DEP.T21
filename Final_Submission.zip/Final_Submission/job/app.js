require("dotenv").config()
const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const session = require("express-session");
const MongoDBSession = require("connect-mongodb-session")(session);
const app = express();
const control = require("./func");
const MongoURI = process.env.MONGO_URL;
const multer = require("multer");


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.set('view engine', 'ejs');


mongoose.connect(MongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(res => {
    console.log("Mongo DB connnected");
});

const store = new MongoDBSession({
    uri: MongoURI,
    collection: "mySessions",
});

app.use(session({
    secret: "wall rose",
    resave: false,
    saveUninitialized: false,
    store: store,
}));

const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        return cb(null, "./uploads");
    },
    filename: function(req, file, cb) {
        return cb(null, `${file.originalname}-${Date.now()}`);
    },
});

const upload = multer({ storage });

app.get("/", control.isAuth, control.start);

app.post("/Verify", control.post_login);

app.get("/OTP_Verifying", control.optAuth, control.OTP_Verifying);

app.post("/authentication", control.login_authentication)

app.get("/dashboard", control.valid, control.dashboard);

app.get("/signUP", control.isAuth, control.signup);

app.post("/signUP", control.isAuth, control.post_signUP);

app.get("/emailVerify", control.emailVerify);

app.post("/verification", control.verification);

app.post("/logout", control.logout);

app.get("/logout", control.logout);

app.get("/applicants/:job_id", control.companyUser, control.view_applicant);

app.post("/company/post_a_job", control.companyUser, control.post_a_job);

app.get("/post", control.companyUser, control.jobform);

app.get("/company_job", control.companyUser, control.company_job);

app.get("/job_description/:job_id", control.aspirantUser, control.job_description);

app.post("/withdraw/:job_id", control.aspirantUser, control.withdraw);

app.get("/applied_job", control.aspirantUser, control.applied_jobs);

app.get("/profile", control.aspirantUser, control.profile);

app.get("/edit_profile", control.aspirantUser, control.edit_profile);

app.post("/post_edit_profile", control.aspirantUser, control.post_edit_profile);

app.post("/apply/:job_id", control.aspirantUser, upload.single("resume"), control.apply);

app.get("/company/job_description/:job_id", control.companyUser, control.company_job_description);

app.post("/delete_job/:job_id", control.companyUser, control.delete_job);

app.get("/resume/:job_id/:applicant_id", control.companyUser, control.resume_download);


const PORT = process.env.PORT;

app.listen(PORT, function(req, res) {

    console.log("server is up!");
})