const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const jobSchema = new Schema({
    job_title: String,
    description: String,
    location: String,
    posting_date: String,
    last_date: String,
    salary: String,
    job_type: String,
    job_link: String,
    responsibility: String,
    qualification: String,
    company_id: String,
    company_name: String,
    no_of_vacancy: Number,
    job_staus: String,
});


module.exports = mongoose.model("Job", jobSchema);