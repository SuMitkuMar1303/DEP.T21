const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const userSchema = new Schema({
    email: String,
    login_type: Number,
    First_name: String,
    last_name: String,

});

// some error here

module.exports = mongoose.model("User", userSchema);
// console.log(userSchema);

// module.exports = mongoose.models.User || mongoose.model("User", userSchema);