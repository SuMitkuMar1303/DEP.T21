var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: '2020csb1039@iitrpr.ac.in',
        pass: 'armaan101101'
    }
});


function OTP() {
    return Math.floor(Math.random() * 1000000) + 1;
}

exports.send_OTP = function(email) {
    var otp = OTP();
    console.log(email + "------\n");
    var mailOptions = {
        from: '2020csb1039@iitrpr.ac.in',
        to: email,
        subject: 'Sending Email using Node.js',
        text: "Your OTP for verification is " + otp + " ."
    };
    transporter.sendMail(mailOptions, function(error, info) {
        if (error) {
            console.log(error);
            return -1;
        } else {
            console.log('Email sent: to ' + user_email);
        }
    });
    console.log(otp + "----\n");
    return otp;
}