const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const CVSchema = new Schema({
    job_id: String,
    applicant_id: String,
    applied_date: String,
    pdf: {
        data: Buffer,
        contentType: String
    },
    coverletter: String,
    filename: String
});


module.exports = mongoose.model("resume", CVSchema);