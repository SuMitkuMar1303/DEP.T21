const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const aspirantSchema = new Schema({
    username: String,
    fname: String,
    mname: String,
    lname: String,
    gender: String,
    phone_number: Number,
    present_address: String,
    permanent_address: String,
    marital_status: String,
    birth_date: Date,
    area_of_specialization: String,
    current_area_of_research: String,

    doctor_degree_name: String,
    doctor_university: String,
    doctor_specialization: String,
    doctor_join: Date,
    doctor_leave: Date,
    thesis_def: String,

    post_degree_name: String,
    post_university: String,
    post_specialization: String,
    post_join: Date,
    post_leave: Date,
    post_gpa: String,

    under_degree_name: String,
    under_university: String,
    under_specialization: String,
    under_join: Date,
    under_leave: Date,
    under_gpa: String,

    exp1: String,
    exp2: String,
    exp3: String,
    add_detail: String,
});


module.exports = mongoose.model("aspirant", aspirantSchema);