// const mongoose = require("mongoose");
// const Schema = mongoose.Schema;


// const eduSchema = new Schema({
//     email_id: String,
//     fname: String,
//     mname: String,
//     lnmae: String,
//     gender: String,
//     phone_number: Number,
//     present_address: String,
//     permanent_address: String,
//     marital_status: String,
//     birth_date: Date,
//     area_of_specialization: String,
//     current_area_of_research: String,
// });


// module.exports = mongoose.model("Job", eduSchema);