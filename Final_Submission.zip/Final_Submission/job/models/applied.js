const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const appliedSchema = new Schema({
    username: String,
    job_id: String,
    resume: String,
    coverletter: String,
});


module.exports = mongoose.model("applied", appliedSchema);