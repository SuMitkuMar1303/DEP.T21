const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const companySchema = new Schema({
    company_id: String,
    company_name: String,
    company_add: String,
    company_email: String,
    company_phone: Number,
    company_website: String,
    logo: {
        data: Buffer,
        contentType: String
    }
});


module.exports = mongoose.model("company", companySchema);