const User = require("./models/user.js");
const Jobs = require("./models/jobs.js");
const Aspirant = require("./models/aspirant.js");
const fs = require("fs");
const Company = require("./models/company.js");
const { send_OTP } = require("./models/email");
const multer = require("multer");
const CV = require("./models/resume.js");
const aspirant = require("./models/aspirant.js");
const jobs = require("./models/jobs.js");



exports.isAuth = (req, res, next) => {
    if (!req.session.isAuth) {
        next();
    } else {
        res.redirect("/dashboard");
    }
};

exports.valid = (req, res, next) => {
    if (req.session.isAuth) {
        next();
    } else {
        res.redirect("/");
    }
}

exports.aspirantUser = (req, res, next) => {
    if (req.session.isAuth) {
        if (req.session.login_type == 1) {
            next();

        } else {
            res.redirect("/");
        }
    } else {
        res.redirect("/");
    }
}


exports.companyUser = (req, res, next) => {
    if (req.session.isAuth) {
        if (req.session.login_type == 2) {
            next();
        } else {
            res.redirect("/");
        }
    } else {
        res.redirect("/");
    }
}


exports.optAuth = (req, res, next) => {
    if (req.session.otp_verify) {
        next();
    } else {
        delete req.session.username;
        delete req.session.otp;
        res.redirect("/");
    }
};

exports.start = async(req, res) => {
    req.session.isAuth = false;
    const error = req.session.error;
    delete req.session.error;
    let x = await User.findOne({ email: "2020csb1104@iitrpr.ac.in" });
    if (!x) {
        x = new User({
            email: "2020csb1104@iitrpr.ac.in",
            login_type: 2,
            First_name: "Nitin",
            last_name: "agrawal",

        });
        await x.save();
        let y = new Company({
            company_id: "2020csb1104@iitrpr.ac.in",
            company_name: "IIT Ropar",
            company_add: "BW303",
            company_email: "Nitin@agrawal.com",
            company_phone: "12345",
            company_website: "www.google.com",
        })
        await y.save();
    }

    res.render('login', { msg: error });
};

exports.post_login = async(req, res) => {
    const email = req.body.email;
    let user = await User.findOne({ email });
    if (user) {
        req.session.username = email;
        req.session.otp_verify = true;
        req.session.isAuth = false;
        res.redirect("/OTP_Verifying");
    } else {
        req.session.error = "No Such User";
        return res.redirect("/");
    }
}


exports.OTP_Verifying = async(req, res) => {
    const email = req.session.username;
    req.session.otp_verify = false;
    req.session.otp = send_OTP(email);
    const error = req.session.error;
    delete req.session.error;
    return res.render('signOTP', { email: email, msg: error });
}

exports.login_authentication = async(req, res) => {
    var enter = req.body.first + req.body.second + req.body.third + req.body.fourth + req.body.fifth + req.body.sixth;
    if (enter == req.session.otp) {
        req.session.isAuth = true;
        const email = req.session.username;
        let user = await User.findOne({ email: email });
        if (user.login_type == 1) {
            req.session.login_type = 1;
        } else {
            req.session.login_type = 2;
        }
        res.redirect("dashboard");
    } else {
        req.session.error = "Entered OTP is Wrong\nWe have send an another OTP";
        req.session.otp_verify = true;
        res.redirect("OTP_Verifying");

    }
}



exports.dashboard = async(req, res) => {
    if (req.session.login_type == 1) {
        let aspirant = await Aspirant.findOne({ username: req.session.username });
        if (aspirant == null) {
            res.send("Some Problem at Our End");
        } else {
            let jobs = await Jobs.find({ job_staus: '1' });
            res.render('jobs', { fname: aspirant.fname, jobs: jobs });
        }
    } else if (req.session.login_type == 2) {
        let company = await Company.findOne({ company_id: req.session.username });
        if (company == null) {
            res.send("Some Problem at Our -- End");
        } else {
            req.session.company_name = company.company_name;
            let jobs = await Jobs.find({ company_id: req.session.username });
            res.render('comdash', { name: company.company_name, jobs: jobs });
        }

    } else {
        res.redirect("/");
    }
}

exports.post_a_job = async(req, res) => {
    if (req.session.login_type == 2) {
        let job_item = req.body;
        let x = await Company.findOne({ company_id: req.session.username });
        if (x) {
            // console.log(x.company_name);
            // console.log(x);
        }

        // console.log(job_item);
        let ts = Date.now();

        let date_ob = new Date(ts);
        let date = date_ob.getDate();
        let month = date_ob.getMonth() + 1;
        let year = date_ob.getFullYear();

        let new_job = new Jobs({
            job_title: job_item.title,
            description: job_item.description,
            location: job_item.location,
            qualification: job_item.qualification,
            responsibility: job_item.responsibility,
            posting_date: year + "-" + month + "-" + date,
            last_date: job_item.last_date,
            salary: job_item.salary,
            job_type: job_item.job_type,
            job_link: job_item.job_link,
            company_id: req.session.username,
            company_name: x.company_name,
            no_of_vacancy: job_item.vacancies,
            job_staus: "1",
        })
        await new_job.save();

        res.redirect("/dashboard");
    } else {
        res.send("Don't try to Smart");
    }
}

exports.jobform = async(req, res) => {
    res.render('post', { name: req.session.company_name });
}


exports.logout = async(req, res) => {
    req.session.destroy((err) => {
        if (err) throw err;
        res.redirect("/");
    });

}

// exports.Company_allJob = async(req, res) => {
//     res.render
// }

exports.authentication = async(req, res) => {

}

exports.signup = async(req, res) => {
    let error = req.session.error;
    delete req.session.error;
    res.render('signup', { msg: error });

}

exports.post_signUP = async(req, res) => {
    let email = req.body.email;
    let user = await User.findOne({ email: email });

    if (user == null) {
        req.session.sign_type = 1;
        req.session.username = email;
        req.session.fname = req.body.fname;
        req.session.lname = req.body.lname;
        req.session.signup_verify = true;
        // req.session.signUP_otp = send_OTP(email);
        res.redirect("emailVerify");
    } else {
        req.session.error = "Email Already exist in Database";
        res.redirect("/signUP");
    }
}

exports.emailVerify = async(req, res) => {
    let email = req.session.username;
    req.session.signUP_verify = false;
    req.session.signUP_otp = send_OTP(email);
    const error = req.session.error;
    delete req.session.error;
    return res.render('emailverify', { email: email, msg: error });

}


exports.verification = async(req, res) => {
    var enter = req.body.first + req.body.second + req.body.third + req.body.fourth + req.body.fifth + req.body.sixth;

    if (enter == req.session.signUP_otp) {
        req.session.isAuth = true;
        req.session.login_type = req.session.sign_type;
        let x = new User({
            email: req.session.username,
            login_type: 1,
            First_name: req.session.fname,
            last_name: req.session.lname,
        })
        await x.save();
        let y = new Aspirant({
            username: req.session.username,
            fname: req.session.fname,
            mname: "",
            lname: req.session.lname,
            gender: "",
            phone_number: 0,
            present_address: "",
            permanent_address: "",
            marital_status: "",
            birth_date: "",
            area_of_specialization: "NA",
            current_area_of_research: "",

            doctor_degree_name: "",
            doctor_university: "",
            doctor_specialization: "",
            doctor_join: "",
            doctor_leave: "",
            thesis_def: "",

            post_degree_name: "",
            post_university: "",
            post_specialization: "",
            post_join: "",
            post_leave: "",
            post_gpa: "",

            under_degree_name: "",
            under_university: "",
            under_specialization: "",
            under_join: "",
            under_leave: "",
            under_gpa: "",

            exp1: "",
            exp2: "",
            exp3: "",
            add_detail: "",
        });
        await y.save()
        res.redirect("/dashboard");

    } else {
        req.session.signUP_verify = true;
        req.session.error = "Entered OTP is Wrong\nWe have send an another OTP";
        res.redirect("emailVerify");
    }
}



exports.company_job = async(req, res) => {
    // console.log(req.session.username);
    let job = await Jobs.find({ company_id: req.session.username });
    // console.log(job);
    let company = await Company.findOne({ company_id: req.session.username });
    res.render('company_job', { jobs: job, name: company.company_name });
}



exports.apply = async(req, res) => {
    // handle large file size
    var resume = fs.readFileSync(req.file.path);
    let encode_file = resume.toString('base64');
    let ts = Date.now();

    let date_ob = new Date(ts);
    let date = date_ob.getDate();
    let month = date_ob.getMonth() + 1;
    let year = date_ob.getFullYear();

    let cv = new CV({
        job_id: req.params.job_id,
        applicant_id: req.session.username,
        applied_date: year + "-" + month + "-" + date,
        pdf: {
            data: new Buffer.from(encode_file, 'base64'),
            contentType: req.file.mimetype
        },
        coverletter: req.body.coverletter,
        filename: req.file.filename

    })

    await cv.save();


    fs.unlinkSync(req.file.path);
    // send email
    res.redirect("/");

    // send a resume file

    // let x = await CV.findOne({ job_id: "ghgh" });
    // let z = "/download";
    // // console.log(x);
    // await decodeBase64ToPdf(x.pdf.data, __dirname + "\download");
    // let data = fs.readFileSync(__dirname + "/download/xyz.pdf");
    // fs.unlinkSync(__dirname + "/download/xyz.pdf");
    // res.setHeader('Content-Type', 'application/pdf');
    // res.setHeader('Content-Disposition', 'attachment; filename=file.pdf');
    // res.end(data);

    // console.log(req.body);
    // console.log(req.file);

    // res.send()
}



exports.job_description = async(req, res) => {

    let job_id = req.params.job_id;
    let job = await Jobs.findOne({ _id: job_id });
    if (job == null) {
        res.redirect("/");
    } else {
        // console.log(job);
        // console.log(job.location);
        let user = await aspirant.findOne({ username: req.session.username });

        let x = await CV.findOne({ job_id: job_id, applicant_id: req.session.username })
        let y = 1;
        if (x == null) {
            y = 0;
        }

        // res.sendFile(__dirname + "/job_description.html")0
        res.render('job_description', { job: job, fname: user.fname, lname: user.lname, email: user.username, applied: y });
    }
    // res.render('job_description', { job: job, fname: user.fname, lname: user.lname, email: req.session.username });
}


// exports.applied_job = async(req, res) => {
//     res.redirect("/");

// }

exports.withdraw = async(req, res) => {
    let job_id = req.params.job_id;
    await CV.deleteOne({ job_id: job_id, applicant_id: req.session.username });

    // send email

    // res.redirect("/applied_job");
    res.redirect("/");
}

exports.applied_jobs = async(req, res) => {
    let x = await CV.find({ applicant_id: req.session.username });
    let y = [];
    for (let i = 0; i < x.length; i++) {
        // console.log(x[i].job_id);
        let z = await Jobs.findOne({ _id: x[i].job_id })
        y.push(z);
    }
    let aspirant = await Aspirant.findOne({ username: req.session.username });
    if (aspirant == null) {
        res.send("Some Problem at Our End");
    } else {
        // let jobs = await Jobs.find({ job_staus: '1' });
        // console.log(jobs);
        // console.log(y);
        // console.log("=========");
        res.render('applied_job', { fname: aspirant.fname, jobs: y });
        // res.render('jobs', { fname: aspirant.fname, jobs: jobs });
    }
}


exports.profile = async(req, res) => {
    let y = await aspirant.findOne({ username: req.session.username });
    if (y == null) {
        res.redirect("/");
    } else {
        res.render('profile', { user: y })
    }

}

exports.edit_profile = async(req, res) => {
    let y = await aspirant.findOne({ username: req.session.username });
    // console.log(y);

    res.render('edit_profile', { user: y })
}

exports.post_edit_profile = async(req, res) => {
    let x = req.body;
    // console.log(req.body);
    let update = {
            fname: x.fname,
            mname: x.mname,
            lname: x.lname,
            gender: x.gender,
            phone_number: x.phone_number,
            present_address: x.present_address,
            permanent_address: x.permanent_address,
            marital_status: x.marital_status,
            birth_date: x.birth_date,
            area_of_specialization: x.area_of_specialization,
            current_area_of_research: x.current_area_of_research,

            doctor_degree_name: x.doctor_degree_name,
            doctor_university: x.doctor_university,
            doctor_specialization: x.doctor_specialization,
            doctor_join: x.doctor_join,
            doctor_leave: x.doctor_leave,
            thesis_def: x.thesis_def,

            post_degree_name: x.post_degree_name,
            post_university: x.post_university,
            post_specialization: x.post_specialization,
            post_join: x.post_join,
            post_leave: x.post_leave,
            post_gpa: x.post_gpa,

            under_degree_name: x.under_degree_name,
            under_university: x.under_university,
            under_specialization: x.under_specialization,
            under_join: x.under_join,
            under_leave: x.under_leave,
            under_gpa: x.under_gpa,

            exp1: x.exp1,
            exp2: x.exp2,
            exp3: x.exp3,
            add_detail: x.add_detail,




        }
        // console.log("Update");
        // console.log(update);
    let a = await aspirant.findOne({ username: req.session.username });
    // console.log("result");

    // console.log(a);

    await aspirant.updateOne({ username: req.session.username }, update)
    res.redirect("/");
}

exports.page = async(req, res) => {
    let job = await Jobs.findOne({ company_id: "2020csb1104@iitrpr.ac.in" });
    // console.log(job._id.toString());
    res.render('company_job_description', { job: job, fname: "nitu", lname: "", email: "agrawal studio" });
}

exports.company_job_description = async(req, res) => {
    let job_id = req.params.job_id;
    let job = await Jobs.findOne({ _id: job_id });
    let company = await Company.findOne({ company_id: req.session.usernmae });
    // res.render('company_job_description', { job: job, link: company.company_website });
    res.render('company_job_description', { job: job, link: "www.google.com" });
}

exports.delete_job = async(req, res) => {
    let job_id = req.params.job_id;
    await jobs.deleteOne({ _id: job_id });
    await CV.deleteMany({ job_id: job_id });
    res.redirect("/");
}

exports.view_applicant = async(req, res) => {

    let job_id = req.params.job_id;
    let job = await Jobs.findOne({ _id: job_id });
    if (job == null) {
        res.redirect("/");
    } else {
        let x = await CV.find({ job_id: job_id });
        let y = [];
        let k = [];
        for (let i = 0; i < x.length; i++) {
            let z = await aspirant.findOne({ username: x[i].applicant_id });
            k.push(x[i].applied_date);
            y.push(z);
        }

        // console.log(y)

        res.render('job_applicant', { user: y, dat: k, job_id, job_id });
    }

}

async function decodeBase64ToPdf(encodedString, outputFilePath) {
    const decodedData = Buffer.from(encodedString, 'base64');
    await fs.writeFileSync(outputFilePath,  decodedData);
}

exports.resume_download = async(req, res) => {
    let job_id = req.params.job_id;
    let applicant_id = req.params.applicant_id;


    let x = await CV.findOne({ job_id: job_id, applicant_id: applicant_id });
    let z = "/download";
    // // console.log(x);
    // await decodeBase64ToPdf(x.pdf.data, __dirname + `/download/${x.filename}`);
    // let data = fs.readFileSync(__dirname + `/download/${x.filename}`);
    await decodeBase64ToPdf(x.pdf.data, __dirname + `/download/${applicant_id}.pdf`);
    let data = fs.readFileSync(__dirname + `/download/${applicant_id}.pdf`);
    fs.unlinkSync(__dirname + `/download/${applicant_id}.pdf`);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=${applicant_id}.pdf`);
    res.end(data);

    // console.log(req.body);
    // console.log(req.file);

    // res.send()
}

exports.page2 = async(req, res) => {
    res.render('company_signup', { msg: "" });
}