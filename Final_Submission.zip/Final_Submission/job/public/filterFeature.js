// get references to the filter elements
const categoryFilter = document.getElementById("category-filter");

// get references to all the job card elements
const jobCards = document.querySelectorAll(".job-card");

// add an event listener to the category filter dropdown
categoryFilter.addEventListener("change", function () {
  // get the selected category value
  const selectedCategory = categoryFilter.value;
  
  // loop through all the job card elements
  jobCards.forEach(function (card) {
    // get the category value of the current card
    const cardCategory = card.getAttribute("data-category");
    
    // check if the selected category matches the card category
    if (selectedCategory === "" || selectedCategory === cardCategory) {
      // show the card if the category matches
      card.style.display = "block";
    } else {
      // hide the card if the category doesn't match
      card.style.display = "none";
    }
  });
});

// const jobCards = document.querySelectorAll(".job-card");
const locationFilter = document.getElementById('location-filter');

locationFilter.addEventListener("change", function() {
  const selectedLocation = locationFilter.value;

  jobCards.forEach(function(card) {
    const cardLocation = card.getAttribute("data-location");

    if (selectedLocation === "" || selectedLocation === cardLocation) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }
  });
});

